## ODAM using Apache Web server

Deploy the ODAM API with a very lightweight local web server for Windows.

##  HOWTO
 * Download and Unzip ODAMwebserver.zip to the location of your choice on your hard drive
 
 * Go to the directory usbwebserver\settings, then with the notepad application for example, edit the getdata.conf file.
 * In the line starting with DATAROOT, specify the full path of the root of the data directory (be careful, it is necessary to put slashes "/" and not backslashes "\")
 * Save the configuration file, then exit
 
 * Run WebServer.bat. A small window opens, indicating whether the Apache server is running or not.
 * At the first run, Windows should ask you for permission to pass through the firewall. Validate the authorization so that the web server can function properly.
 * Also, if the system tells you that the libssh2.dll file is missing, don't worry, it will still work.

 * In your browser, go To http://localhost/ to view your site root and to http://localhost/getdata/xml/<dataset> to view the <dataset> where <dataset> correspondings to your dataset put under the root of the data directory.

 * Then, proceed as indicated in the 'Deployment and User's Guide' - https://inrae.github.io/odam-docs/ for using the API
