<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>ODAMwebserver</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
	<div id="container">
		<div id="topcontent"></div>
		<div id="content">
			<div id="contentleft">

				<h1>ODAM Web Server V 1.0</h1>
				<br><br>
				<h1>PHP <?php echo phpversion(); ?> info</h1>
				<?php
					ob_start();
					phpinfo();
					$i = ob_get_contents();
					ob_end_clean();					
					echo ( preg_replace ( '%^.*<body>(.*)</body>.*$%ms', '$1', $i ) ) ;
				?>
			
			</div>
			<br style="clear:both">
		</div>
	</div>
</body>
</html>
		